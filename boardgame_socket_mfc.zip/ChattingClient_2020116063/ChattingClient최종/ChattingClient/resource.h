//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// ChattingClient.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDC_BUTTON_SEND                 2
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_CHATTINGCLIENT_DIALOG       102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDD_DIALOG1                     129
#define IDB_BITMAP1                     130
#define IDB_BITMAP2                     131
#define IDB_BITMAP3                     132
#define IDB_BITMAP4                     133
#define IDB_BITMAP5                     134
#define IDB_BITMAP6                     135
#define IDB_BITMAP7                     136
#define IDB_SOUND                       138
#define IDC_LIST1                       1000
#define IDC_EDIT1                       1001
#define IDC_IPADDRESS1                  1002
#define IDC_BUTTON2                     1004
#define IDC_BUTTON_CONNECT              1004
#define IDC_BUTTON1                     1005
#define IDC_RADIO1                      1007
#define IDC_RADIO2                      1008
#define IDC_RADIO3                      1009
#define IDC_RADIO4                      1010
#define IDC_BUTTON3                     1011
#define IDC_LIST2                       1012
#define IDC_LIST3                       1013
#define IDC_EDIT2                       1014
#define IDC_LIST4                       1015
#define IDC_LIST5                       1016
#define IDC_DICE1                       1017
#define IDC_DICE2                       1018

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        139
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
